/*
Ali Arslan
1210505017
Inheritance ile birlikte Serialization nasıl kullanılır?
*/


import java.io.FileOutputStream; // java.io paketlerini içe aktarıyoruz.
import java.io.ObjectOutputStream;
import java.io.FileInputStream;
import java.io.ObjectInputStream;

public class Main{
    public static void main(String[] args){
        System.out.println(" \nOgrenci adi: Ali Arslan \nOgrenci numarasi: 1210505017 \nProje konusu: Inheritance ile birlikte Serialization nasıl kullanılır? \n");
        try{
            Araba araba = new Araba("opel", "astra");
            FileOutputStream file = new FileOutputStream("output.txt"); // ObjectOutputStream'deki nesnelerin yazıldığı bir FileOutputStream oluşturuyoruz.
            ObjectOutputStream write = new ObjectOutputStream(file); // ObjectOutputStream'i oluşturuyoruz.
            write.writeObject(araba);

            // Nesneyi Okumak
            FileInputStream fileIn = new FileInputStream("output.txt");
            ObjectInputStream read = new ObjectInputStream(fileIn); // ObjectInputStream sınıfını, daha önce ObjectOutputStream tarafından yazılmış nesneleri okumak için kullanıyoruz.

            Araba newAraba = (Araba) read.readObject();

            System.out.println("Araba markasi: " + newAraba.getMarka());
            System.out.println("Araba modeli: " + newAraba.getModel());

            read.close();
            write.close();




        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }



    }
}