
import java.io.Serializable;

public class Araba implements Serializable{ // Serileştirilecek nesnemizin serileştirilebilir (serializable) olduğunu sınıf başında belirtiyoruz.


    private String marka;
    private String model;

    Araba(String marka, String model){
        this.marka = marka;
        this.model = model;

    }

    public String getMarka(){
        return marka;
    }
    public void setMarka(String marka){
        this.marka = marka;
    }
    public String getModel(){
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }
}
