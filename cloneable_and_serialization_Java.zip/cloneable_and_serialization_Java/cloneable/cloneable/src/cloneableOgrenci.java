// Clonable interface'den kalıtım alacak  bütün sınıflar clone edilebilir özelliği kazanır.

public class cloneableOgrenci extends insan implements Cloneable {
    Object copy() throws CloneNotSupportedException { // Bu metod ile klonlama özelliği kazandırılır.
        return this.clone();

    }

}

