// Clonable interface'den kalıtım alacak  bütün sınıflar clone edilebilir özelliği kazanır.

public class insan implements Cloneable{
    int boy;
    int kilo;
    int yas;
    String cinsiyet;
}
