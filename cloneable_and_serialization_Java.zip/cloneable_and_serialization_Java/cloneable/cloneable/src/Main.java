/*
Ali Arslan
1210505017
Cloneable interface nedir?

*/

public class Main {
    public static void main(String[] args) throws CloneNotSupportedException {

        System.out.println(" \nOgrenci adi: Ali Arslan \nOgrenci numarasi: 1210505017 \nProje konusu: Cloneable interface nedir? \n");

        cloneableOgrenci ali = new cloneableOgrenci();
        ali.boy = 172;
        ali.cinsiyet = "erkek";
        ali.yas = 22;
        ali.kilo = 75;
        cloneableOgrenci fatma = (cloneableOgrenci) ali.copy(); // Burada ali classının klonuna fatma ismini veriyoruz.
        fatma.boy = 160;
        fatma.cinsiyet = "kadin";
        fatma.yas = 20;
        fatma.kilo = 55;
        System.out.println("alinin boyu " + ali.boy);
        System.out.println("fatmanin boyu " + fatma.boy);
        System.out.println("alinin kilosu " + ali.kilo);
        System.out.println("fatmanin kilosu " + fatma.kilo);
        System.out.println("alinin cinsiyeti " + ali.cinsiyet);
        System.out.println("fatmanın cinsiyeti " + fatma.cinsiyet);
        System.out.println("alinin yasi " + ali.yas);
        System.out.println("fatmanin yasi " + fatma.yas);

    }
}